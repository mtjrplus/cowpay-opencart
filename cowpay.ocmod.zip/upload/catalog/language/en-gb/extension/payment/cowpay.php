<?php

$_['entry_cardname'] = 'Placeholder name';
$_['entry_cardnumber'] = 'Card number';
$_['entry_expirydate'] = 'Expiry date (mm/yy)';
$_['entry_securitycode'] = 'CVV';
$_['cowpay_creditcard_title'] = 'Please enter your credit card details';
$_['error_required'] = "Please be sure to enter all fields properly";
$_['error_failed'] = 'The payment proccess can not be completed. Please contact the store administration or choose another payment method';
$_['error_invalid'] = 'Invalid card data';
$_['error_insufficient'] = 'Insufficient card funds';